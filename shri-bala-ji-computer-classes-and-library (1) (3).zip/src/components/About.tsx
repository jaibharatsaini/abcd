import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 bg-white dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Our Vision</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-academic-blue dark:text-white mb-8 leading-tight">
              Bridging Tradition with <span className="italic text-academic-accent">Modern Technology</span>
            </h3>
            <p className="text-lg text-slate-600 dark:text-slate-300 mb-8 leading-relaxed">
              Shri Bala Ji Computer Classes and Library was established to solve the dual challenges faced by local students: the need for a distraction-free library and access to high-end computing resources. We provide a 360° academic support system where students can research from physical books and immediately apply their learning on modern digital systems.
            </p>
            
            <div className="space-y-4">
              {[
                "Combined reading and digital workspace",
                "Advanced computer lab with fiber-speed internet",
                "Dedicated zones for silent study and collaborations",
                "In-house printing, scanning, and digital support",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0" />
                  <span className="text-slate-700 dark:text-slate-200 font-medium">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>

          <div className="grid grid-cols-2 gap-4 relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              viewport={{ once: true }}
              className="mt-12"
            >
              <img
                src="/src/assets/images/library_silent_zone.png"
                alt="Modern library study space with focused students"
                className="rounded-3xl shadow-xl w-full object-cover aspect-[3/4]"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true }}
            >
              <img
                src="/src/assets/images/student_study_notes.png"
                alt="Student studying books and making notes in library"
                className="rounded-3xl shadow-xl w-full object-cover aspect-[3/4]"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            
            {/* Absolute element */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-academic-blue text-white p-8 rounded-3xl shadow-2xl hidden md:block">
              <div className="text-4xl font-serif font-bold mb-1">5+</div>
              <div className="text-sm opacity-80 uppercase tracking-widest">Years of Trust</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
