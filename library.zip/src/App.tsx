/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Features from './components/Features';
import Membership from './components/Membership';
import BookCategories from './components/BookCategories';
import Courses from './components/Courses';
import Availability from './components/Availability';
import Gallery from './components/Gallery';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  useEffect(() => {
    // Add smooth scrolling for all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        if (!href || href === '#') return;
        
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth'
          });
        }
      });
    });
  }, []);

  return (
    <div className="min-h-screen selection:bg-academic-blue/20">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Features />
        <BookCategories />
        <Courses />
        <Availability />
        <Membership />
        <Gallery />
        <Testimonials />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      
      {/* Scroll to Top Button (Hidden by default, shown via CSS interaction if needed or just simple bottom right) */}
      <a 
        href="#hero" 
        className="fixed bottom-8 right-8 z-40 bg-academic-blue text-white p-3 rounded-full shadow-2xl hover:bg-academic-blue/90 hover:scale-110 active:scale-95 transition-all md:flex hidden items-center justify-center"
        aria-label="Scroll to top"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
        </svg>
      </a>
    </div>
  );
}

