import { motion } from 'motion/react';
import { Phone, Mail, MapPin, MessageCircle, Send, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-white dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Info Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Contact Us</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-academic-blue dark:text-white mb-8 leading-tight">
              Start Your <span className="italic text-academic-accent">Learning Journey</span> Today
            </h3>
            
            <div className="space-y-8 mb-12">
              <div className="flex gap-6">
                <div className="w-14 h-14 bg-academic-blue text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                  <MapPin className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-academic-blue dark:text-white mb-1">Library Address</h4>
                  <p className="text-slate-600 dark:text-slate-400">Near New Era World School, Guriani, Rewari</p>
                </div>
              </div>

              <div className="flex gap-6">
                <div className="w-14 h-14 bg-academic-accent text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                  <Phone className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-academic-blue dark:text-white mb-1">Talk to Us</h4>
                  <p className="text-slate-600 dark:text-slate-400">Neeraj Sharma</p>
                  <p className="text-slate-600 dark:text-slate-400">+91 82955-53955</p>
                </div>
              </div>

              <div className="flex gap-6">
                <div className="w-14 h-14 bg-[#25D366] text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                  <img 
                    src="https://cdn.simpleicons.org/whatsapp/white" 
                    alt="WhatsApp Logo" 
                    className="w-8 h-8"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-academic-blue dark:text-white mb-1">WhatsApp Support</h4>
                  <p className="text-slate-600 dark:text-slate-400">Message us for quick seat availability check.</p>
                  <a 
                    href="https://wa.me/918295553955" 
                    className="text-green-600 font-bold hover:underline" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    id="whatsapp-contact-link"
                  >
                    Chat via WhatsApp
                  </a>
                </div>
              </div>

              <div className="flex gap-6">
                <div className="w-14 h-14 bg-slate-800 text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                  <Clock className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-academic-blue dark:text-white mb-1">Office Hours</h4>
                  <p className="text-slate-600 dark:text-slate-400">Reception: 9:00 AM - 7:00 PM</p>
                  <p className="text-slate-600 dark:text-slate-400 italic">Library: 24/7 for Members</p>
                </div>
              </div>
            </div>

            <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-64 border-4 border-white dark:border-slate-800">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3511.9688755675845!2d76.4357773!3d28.3292415!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39129bc5c30f9a23%3A0xe74f9d0c641c888e!2sGuriani%2C%20Haryana!5e0!3m2!1sen!2sin!4v1715494000000!5m2!1sen!2sin"
                className="w-full h-full grayscale opacity-80"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </motion.div>

          {/* Form Side */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-academic-beige dark:bg-slate-900/50 p-8 md:p-12 rounded-[3.5rem] border border-slate-100 dark:border-slate-800"
          >
            <h4 className="text-2xl font-serif font-bold text-academic-blue dark:text-white mb-8">Send us an Inquiry</h4>
            <form className="space-y-6" id="contact-form">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Full Name</label>
                  <input
                    type="text"
                    className="w-full px-5 py-4 bg-white dark:bg-slate-800 border-none rounded-2xl shadow-sm focus:ring-4 focus:ring-academic-blue/10 outline-none transition-all dark:text-white"
                    placeholder="John Doe"
                    id="contact-name"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Phone Number</label>
                  <input
                    type="tel"
                    className="w-full px-5 py-4 bg-white dark:bg-slate-800 border-none rounded-2xl shadow-sm focus:ring-4 focus:ring-academic-blue/10 outline-none transition-all dark:text-white"
                    placeholder="+91 00000-00000"
                    id="contact-phone"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Target Exam (Optional)</label>
                <select className="w-full px-5 py-4 bg-white dark:bg-slate-800 border-none rounded-2xl shadow-sm focus:ring-4 focus:ring-academic-blue/10 outline-none transition-all dark:text-white appearance-none" id="contact-exam">
                  <option>UPSC / Civil Services</option>
                  <option>SSC / CGL</option>
                  <option>Banking / Railway</option>
                  <option>Engineering (JEE/GATE)</option>
                  <option>School/College Exams</option>
                  <option>Other / General Reading</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Your Message</label>
                <textarea
                  className="w-full px-5 py-4 bg-white dark:bg-slate-800 border-none rounded-2xl shadow-sm focus:ring-4 focus:ring-academic-blue/10 outline-none transition-all dark:text-white min-h-[150px]"
                  placeholder="I want to inquire about monthly membership..."
                  id="contact-message"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-5 bg-academic-blue text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-3 hover:bg-academic-blue/90 hover:shadow-xl transition-all active:scale-95 shadow-md"
                id="contact-submit"
              >
                Send Message
                <Send className="w-5 h-5" />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
