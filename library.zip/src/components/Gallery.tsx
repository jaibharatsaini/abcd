import { motion } from 'motion/react';

const images = [
  { 
    src: "https://images.unsplash.com/photo-1544652478-6653e09f18a2?auto=format&fit=crop&q=80&w=800", 
    title: "Premium Individual Cabins", 
    span: "md:col-span-2 md:row-span-2",
    id: "gallery-img-premium-cabins"
  },
  { 
    src: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=800", 
    title: "Silent Desk Study Areas", 
    span: "",
    id: "gallery-img-study"
  },
  { 
    src: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800", 
    title: "Ethical Hacking & Cyber", 
    span: "",
    id: "gallery-img-hacking"
  },
  { 
    src: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=800", 
    title: "Digital Research Lab", 
    span: "md:col-span-2",
    id: "gallery-img-research"
  },
];

export default function Gallery() {
  return (
    <section id="gallery" className="py-24 bg-white dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Environment</h2>
          <h3 className="text-4xl font-serif font-bold text-academic-blue dark:text-white">
            Where <span className="italic text-academic-accent">Silence</span> Speaks Volumes
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 auto-rows-[250px]">
          {images.map((img, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`relative group overflow-hidden rounded-[2rem] ${img.span}`}
            >
              <img
                src={img.src}
                alt={img.title}
                id={img.id}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-academic-blue/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-8">
                <h4 className="text-white text-xl font-serif font-bold">{img.title}</h4>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
