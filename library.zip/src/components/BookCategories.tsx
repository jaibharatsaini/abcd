import { motion } from 'motion/react';
import { Book, GraduationCap, Building2, FlaskConical, Languages, Palette, Newspaper } from 'lucide-react';

const categories = [
  { name: "Haryana GK", icon: Building2, color: "bg-blue-500", count: "120+ E-Books" },
  { name: "UPSC & Civil Services", icon: GraduationCap, color: "bg-amber-600", count: "450+ E-Resources" },
  { name: "SSC & Banking", icon: Book, color: "bg-emerald-600", count: "300+ E-Books" },
  { name: "Engineering / JEE", icon: FlaskConical, color: "bg-indigo-600", count: "180+ E-Resources" },
  { name: "Hindi Literature", icon: Languages, color: "bg-rose-600", count: "200+ E-Books" },
  { name: "Self Growth / Novels", icon: Palette, color: "bg-purple-600", count: "250+ E-Resources" },
  { name: "Current Affairs", icon: Newspaper, color: "bg-slate-700", count: "Daily E-Resources" },
];

export default function BookCategories() {
  return (
    <section id="books" className="py-24 bg-academic-beige dark:bg-slate-900 border-y border-slate-100 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div className="max-w-2xl">
            <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Our Library Stack</h2>
            <h3 className="text-4xl font-serif font-bold text-academic-blue dark:text-white leading-tight">
              Curated Resources for <span className="italic text-academic-accent">Every Aspirant</span>
            </h3>
          </div>
          <p className="text-slate-600 dark:text-slate-400 md:max-w-xs italic text-sm">
            "The library is the only single place where you can find anything and everything about everything."
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {categories.map((cat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group cursor-pointer"
            >
              <div className="aspect-square bg-white dark:bg-slate-800 rounded-3xl p-6 flex flex-col items-center justify-center text-center shadow-sm border border-slate-100 dark:border-slate-700 group-hover:border-academic-blue/30 group-hover:shadow-xl transition-all h-full">
                <div className={`w-12 h-12 ${cat.color} text-white rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <cat.icon className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-academic-blue dark:text-white mb-1 line-clamp-2 leading-tight">{cat.name}</h4>
                <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">{cat.count}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
