import { Library, Facebook, Twitter, Instagram, Linkedin, ArrowUp } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white pt-24 pb-12 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <Library className="w-8 h-8 text-academic-accent" />
              <span className="font-serif text-2xl font-bold">Shri Bala Ji Computer Classes and Library</span>
            </div>
            <p className="text-slate-400 leading-relaxed mb-8">
              Empowering the youth through quality education resources and modern computing facilities. Join our community of 500+ successful learners.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-academic-accent hover:text-white transition-all">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 pt-2">Quick Links</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#about" className="hover:text-white transition-colors">About Library</a></li>
              <li><a href="#facilities" className="hover:text-white transition-colors">Our Facilities</a></li>
              <li><a href="#membership" className="hover:text-white transition-colors">Membership Plans</a></li>
              <li><a href="#gallery" className="hover:text-white transition-colors">View Gallery</a></li>
              <li><a href="#faq" className="hover:text-white transition-colors">FAQs</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 pt-2">Hub Services</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-white transition-colors">Library Stack</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Computer Lab</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Online Form Filling</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Printing & Scanning</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Digital Archive</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 pt-2">Weekly Newsletter</h4>
            <p className="text-sm text-slate-400 mb-6">Receive exam alerts, new book arrivals, and motivational study tips every Monday.</p>
            <form className="relative" id="newsletter-form">
              <input
                type="email"
                placeholder="Your email address"
                id="newsletter-email"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 outline-none focus:border-academic-accent transition-all text-sm"
              />
              <button id="newsletter-submit" className="absolute right-2 top-1/2 -translate-y-1/2 bg-academic-accent p-2 rounded-lg hover:scale-105 active:scale-95 transition-all">
                <ArrowUp className="w-5 h-5 rotate-45" />
              </button>
            </form>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-sm text-slate-500">
          <p>© 2024 Shri Bala Ji Computer Classes and Library. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
