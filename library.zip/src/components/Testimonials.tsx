import { motion } from 'motion/react';
import { Quote, Star } from 'lucide-react';

const testimonials = [
  {
    name: "Rohit Sharma",
    role: "UPSC Aspirant",
    content: "The environment here is incredibly disciplined. I've been coming here for 6 months and my productivity has doubled compared to studying at home.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150"
  },
  {
    name: "Rohan",
    role: "SSC Aspirant",
    content: "Affordable, clean, and has all the facilities like high-speed WiFi and RO water. The separate cabins are a lifesaver for focused work.",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&q=80&w=150",
    id: "testimonial-rohan"
  },
  {
    name: "Sneha Gupta",
    role: "B.Tech Student",
    content: "Creativity is intelligence having fun. This library is the perfect place to let that intelligence roam free and focused.",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150"
  }
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-academic-blue dark:bg-slate-900 overflow-hidden relative">
      {/* Background decorations */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" id="testimonials-container">
        <div className="text-center mb-16">
          <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-beige mb-4 opacity-70">Student Reviews</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-white leading-tight">
            Loved by <span className="italic">100+</span> Local Aspirants
          </h3>
        </div>

        <div className="grid md:grid-cols-3 gap-8" id="testimonials-grid">
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              id={t.id || `testimonial-card-${index}`}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white/10 backdrop-blur-md border border-white/10 p-8 rounded-[2.5rem] relative group hover:bg-white/15 transition-colors"
            >
              <Quote className="absolute top-8 right-8 w-12 h-12 text-white/10" />
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-lg text-slate-100 mb-8 leading-relaxed italic">"{t.content}"</p>
              <div className="flex items-center gap-4">
                <img
                  src={t.avatar}
                  alt={t.name}
                  id={`testimonial-avatar-${index}`}
                  className="w-12 h-12 rounded-full border-2 border-white/20 object-cover"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-bold text-white">{t.name}</h4>
                  <p className="text-xs text-white/60">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
