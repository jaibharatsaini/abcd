import { motion } from 'motion/react';
import { Monitor, User, CheckCircle2, AlertCircle } from 'lucide-react';

export default function Availability() {
  const seats = [
    { id: 1, type: 'Library', status: 'available' },
    { id: 2, type: 'Library', status: 'occupied' },
    { id: 3, type: 'Library', status: 'available' },
    { id: 4, type: 'PC', status: 'available' },
    { id: 5, type: 'PC', status: 'occupied' },
    { id: 6, type: 'PC', status: 'available' },
    { id: 7, type: 'Library', status: 'occupied' },
    { id: 8, type: 'PC', status: 'occupied' },
    { id: 9, type: 'Library', status: 'available' },
    { id: 10, type: 'Library', status: 'available' },
    { id: 11, type: 'PC', status: 'available' },
    { id: 12, type: 'Library', status: 'occupied' },
  ];

  return (
    <section className="py-24 bg-slate-50 dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-2xl px-4"
          >
            <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Real-time Hub Status</h2>
            <h3 className="text-4xl font-serif font-bold text-academic-blue dark:text-white mb-6">
              Smart Tracking <span className="italic text-academic-accent">& Seat Booking</span>
            </h3>
            <p className="text-slate-600 dark:text-slate-400 mb-8 mx-auto">
              Check availability from home before visiting. Our smart tracking system updates every 60 seconds to ensure you always find a spot.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
              <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
                <div className="text-3xl font-serif font-bold text-academic-blue dark:text-white mb-1">8/25</div>
                <div className="text-xs uppercase tracking-widest text-slate-500 font-bold">Library Seats Available</div>
                <div className="mt-4 w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-green-500 h-full w-[32%]"></div>
                </div>
              </div>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
                <div className="text-3xl font-serif font-bold text-academic-blue dark:text-white mb-1">3/8</div>
                <div className="text-xs uppercase tracking-widest text-slate-500 font-bold">Lab PCs Available</div>
                <div className="mt-4 w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                  <div className="bg-academic-accent h-full w-[37.5%]"></div>
                </div>
              </div>
            </div>

            <button id="book-seat-availability-cta" className="px-10 py-4 bg-academic-blue text-white rounded-2xl font-bold hover:shadow-2xl hover:-translate-y-1 transition-all active:scale-95">
              Book Your Seat Now
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
