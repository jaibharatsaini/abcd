import { motion } from 'motion/react';
import { Lightbulb, Code2, Terminal, Briefcase, GraduationCap, Laptop } from 'lucide-react';

const courses = [
  { 
    title: "Basic Computer Literacy", 
    desc: "Master Windows, File Explorer, and Essential Settings for everyday usage.",
    icon: Laptop,
    level: "Beginner"
  },
  { 
    title: "MS Office Suite", 
    desc: "In-depth training on Word, Excel, and PowerPoint for professional projects.",
    icon: Briefcase,
    level: "Professional"
  },
  { 
    title: "Typing Mastery", 
    desc: "Improve your WPM speed and accuracy with our dedicated typing software.",
    icon: Terminal,
    level: "Skill"
  },
  { 
    title: "Coding Foundations", 
    desc: "Learn the basics of HTML, CSS, and Logic Building in a supportive environment.",
    icon: Code2,
    level: "Advanced"
  },
  { 
    title: "Digital Exam Prep", 
    desc: "Navigate CBT (Computer Based Test) environments for competitive exams.",
    icon: GraduationCap,
    level: "Aspirant"
  },
  { 
    title: "Digital Awareness", 
    desc: "Internet safety, email etiquette, and online document management.",
    icon: Lightbulb,
    level: "Essential"
  }
];

export default function Courses() {
  return (
    <section id="courses" className="py-24 bg-white dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Upskill Yourself</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-academic-blue dark:text-white mb-6">
            Courses & <span className="italic text-academic-accent">Learning Support</span>
          </h3>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Beyond just a space, we provide structured guidance to help you master the digital tools of the 21st century.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <motion.div
              key={index}
              id={`course-card-${index}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 hover:shadow-xl transition-all group"
            >
              <div className="w-14 h-14 bg-academic-blue text-white rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:rotate-6 transition-transform">
                <course.icon className="w-7 h-7" />
              </div>
              <div className="inline-block px-3 py-1 bg-academic-accent/10 text-academic-accent text-[10px] font-bold uppercase tracking-widest rounded-full mb-4">
                {course.level}
              </div>
              <h4 className="text-xl font-bold text-academic-blue dark:text-white mb-3">{course.title}</h4>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-sm">{course.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
