import { motion } from 'motion/react';
import { ArrowRight, Search, MapPin } from 'lucide-react';

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0" id="hero-background-wrapper">
        <img
          src="https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&q=80&w=1920"
          alt="Modern high-ceiling library with focused students"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          id="hero-bg-image"
        />
        <div className="absolute inset-0 bg-academic-beige/90 dark:bg-slate-950/85"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-academic-blue/10 text-academic-blue rounded-full text-sm font-semibold mb-6" id="location-badge">
              <MapPin className="w-4 h-4" />
              <span>Near New Era World School, Guriani, Rewari</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-academic-blue dark:text-white leading-[1.1] mb-6 text-balance" id="hero-heading">
              Learn, Study, and <span className="italic text-academic-accent">Grow</span> in One Smart Space
            </h1>
            <p className="text-lg md:text-xl text-slate-600 dark:text-slate-300 mb-10 max-w-lg leading-relaxed" id="hero-description">
              Shri Bala Ji Computer Classes and Library combines a peaceful premium library with a modern high-speed computer lab to provide the ultimate learning ecosystem.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4" id="hero-actions">
              <a
                href="#membership"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-academic-blue text-white rounded-xl text-lg font-bold hover:bg-academic-blue/90 transition-all shadow-xl hover:-translate-y-1 active:scale-95 group"
                id="hero-cta-join"
              >
                Join Membership
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white dark:bg-slate-800 text-academic-blue dark:text-white border border-academic-blue/20 rounded-xl text-lg font-bold hover:bg-academic-beige dark:hover:bg-slate-700 transition-all shadow-md"
                id="hero-cta-book"
              >
                Book a Seat
              </a>
            </div>

            {/* Quick Search */}
            <div className="mt-12 max-w-md relative group" id="search-wrapper">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-academic-blue transition-colors w-5 h-5" />
              <input
                type="text"
                placeholder="Search for books or subjects..."
                className="w-full pl-12 pr-4 py-4 bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-transparent focus:border-academic-blue/30 focus:ring-4 focus:ring-academic-blue/5 outline-none transition-all dark:text-white"
                id="book-quick-search"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            viewport={{ once: true }}
            className="hidden lg:block relative"
            id="hero-image-container"
          >
            <div className="relative z-10 rounded-[2rem] overflow-hidden shadow-2xl border-8 border-white dark:border-slate-800 rotate-2">
              <img
                src="https://images.unsplash.com/photo-1544652478-6653e09f18a2?auto=format&fit=crop&q=80&w=800"
                alt="Students studying intensely in a modern library"
                className="w-full aspect-[4/5] object-cover"
                referrerPolicy="no-referrer"
                id="hero-featured-image"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-academic-accent/20 rounded-full blur-3xl opacity-50"></div>
            <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-academic-blue/10 rounded-full blur-3xl opacity-50"></div>
            
            {/* Floating stats */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute top-1/4 -left-12 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-700 z-20"
              id="success-stats-badge"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold">98%</div>
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Success Rate</div>
                  <div className="text-sm font-bold dark:text-white">Exam Aspirants</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
