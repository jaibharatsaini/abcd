import { motion } from 'motion/react';
import { Check, Info } from 'lucide-react';

const plans = [
  {
    name: "Monthly Basic",
    price: "₹700",
    period: "per month",
    features: ["Silent reading zone", "Personal study cabin", "High-speed WiFi", "RO Water & AC"],
    recommended: false,
    details: "Standard library access"
  },
  {
    name: "Monthly Premium",
    price: "₹1,000",
    period: "per month",
    features: ["All Basic features", "FREE Computer access", "Daily Newspaper", "Priority support"],
    recommended: true,
    details: "Best for digital learners"
  },
  {
    name: "3 Months Basic",
    price: "₹1,500",
    period: "Advance payment",
    features: ["Silent reading zone", "Personal study cabin", "High-speed WiFi", "Save ₹600 total"],
    recommended: false,
    details: "Affordable long-term"
  },
  {
    name: "3 Months Premium",
    price: "₹2,000",
    period: "Advance payment",
    features: ["All Monthly Premium", "FREE Computer access", "Personal Space", "Save ₹1000 total"],
    recommended: true,
    details: "Full Academic Hub Access"
  }
];

const computerCourses = [
  {
    name: "3 Months Certificate",
    price: "₹1,000",
    period: "per month",
    total: "₹3,000 Total",
    features: ["Basic Computer Skills", "MS Office Suite", "Internet & Emailing", "Typing Master Class"],
    recommended: false,
  },
  {
    name: "6 Months Diploma",
    price: "₹1,000",
    period: "per month",
    total: "₹6,000 Total",
    features: ["Advanced MS Excel", "Tally & Accounting", "Web Designing Basics", "Software Installation"],
    recommended: true,
  },
  {
    name: "1 Year Professional",
    price: "₹1,000",
    period: "per month",
    total: "₹12,000 Total",
    features: ["Programming Basics", "Graphic Designing", "DTP & Publishing", "Career Guidance"],
    recommended: false,
  }
];

export default function Membership() {
  return (
    <section id="membership" className="py-24 bg-white dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Investment in Future</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-academic-blue dark:text-white mb-6">
            Library <span className="italic text-academic-accent">& Membership</span> Plans
          </h3>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Choose a plan that fits your study schedule. Premium plans include free access to our modern computer lab.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-24">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`relative p-8 rounded-[2.5rem] border flex flex-col ${
                plan.recommended 
                  ? 'border-academic-blue bg-white dark:bg-slate-900 shadow-2xl z-10' 
                  : 'border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50'
              }`}
            >
              {plan.recommended && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-academic-accent text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest whitespace-nowrap shadow-lg">
                  {index === 1 ? 'Most Popular' : 'Best Value'}
                </div>
              )}
              
              <div className="mb-8">
                <h4 className="text-xl font-bold text-academic-blue dark:text-white mb-1">{plan.name}</h4>
                <p className="text-xs text-slate-500 mb-4 font-medium uppercase tracking-tight">{plan.details}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-serif font-black text-slate-900 dark:text-white">{plan.price}</span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">{plan.period}</span>
                </div>
              </div>

              <div className="space-y-4 mb-10 flex-grow">
                {plan.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Check className={`w-4 h-4 flex-shrink-0 ${plan.recommended ? 'text-academic-blue' : 'text-slate-400'}`} />
                    <span className="text-sm text-slate-700 dark:text-slate-200">{feat}</span>
                  </div>
                ))}
              </div>

              <button
                className={`w-full py-4 rounded-2xl font-bold transition-all active:scale-95 ${
                  plan.recommended
                    ? 'bg-academic-blue text-white shadow-xl hover:bg-academic-blue/90'
                    : 'bg-white dark:bg-slate-800 text-academic-blue dark:text-white border border-slate-200 dark:border-slate-700 hover:border-academic-blue/30'
                }`}
              >
                Enroll Now
              </button>
            </motion.div>
          ))}
        </div>

        {/* Professional Computer Courses Section */}
        <div className="text-center mb-16">
          <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">Skill Development</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-academic-blue dark:text-white mb-6">
            Professional <span className="italic text-academic-accent">Computer Courses</span>
          </h3>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Hands-on training by experts. Get certified and ready for your professional career.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {computerCourses.map((course, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`p-8 rounded-[3rem] border ${
                course.recommended 
                  ? 'bg-academic-blue text-white shadow-2xl relative' 
                  : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800'
              }`}
            >
              {course.recommended && (
                <div className="absolute -top-3 right-8 bg-academic-accent text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">
                  Best Seller
                </div>
              )}
              <h4 className={`text-2xl font-bold mb-2 ${course.recommended ? 'text-white' : 'text-academic-blue dark:text-white'}`}>
                {course.name}
              </h4>
              <div className="flex items-baseline gap-2 mb-6">
                <span className="text-4xl font-serif font-black">{course.price}</span>
                <span className={`text-sm ${course.recommended ? 'text-blue-100' : 'text-slate-500'}`}>{course.period}</span>
              </div>
              
              <div className={`text-xs font-bold uppercase tracking-widest mb-8 px-3 py-1 rounded-full inline-block ${
                course.recommended ? 'bg-white/10 text-white' : 'bg-academic-blue/5 text-academic-blue'
              }`}>
                {course.total}
              </div>

              <div className="space-y-4 mb-10">
                {course.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Check className={`w-5 h-5 ${course.recommended ? 'text-academic-accent' : 'text-academic-blue'}`} />
                    <span className={course.recommended ? 'text-blue-50' : 'text-slate-700 dark:text-slate-200'}>{feat}</span>
                  </div>
                ))}
              </div>

              <button
                className={`w-full py-4 rounded-2xl font-bold transition-all active:scale-95 ${
                  course.recommended
                    ? 'bg-academic-accent text-white shadow-lg'
                    : 'bg-academic-blue text-white'
                }`}
              >
                Inquire Course
              </button>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 bg-academic-blue/5 dark:bg-white/5 p-6 rounded-3xl border border-dotted border-academic-blue/20 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-academic-blue rounded-full flex items-center justify-center text-white flex-shrink-0">
              <Info className="w-6 h-6" />
            </div>
            <p className="text-slate-700 dark:text-slate-300 font-medium">
              Are you a group of 5+ students? Contact us for special <span className="text-academic-blue dark:text-academic-accent font-bold">Group Discounts!</span>
            </p>
          </div>
          <a href="#contact" className="px-8 py-3 bg-white dark:bg-slate-800 text-academic-blue font-bold rounded-xl border border-slate-200 hover:shadow-md transition-all">
            Inquire Group Rate
          </a>
        </div>
      </div>
    </section>
  );
}
