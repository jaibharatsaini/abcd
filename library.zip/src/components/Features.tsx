import { motion } from 'motion/react';
import { 
  Wind, Wifi, Battery, Layout, BookOpen, Newspaper, Shield, Droplets, VolumeX, UserCheck,
  Monitor, MousePointer2, Printer, Code, FileText, Keyboard, Cpu, Globe
} from 'lucide-react';

const libraryFeatures = [
  { icon: VolumeX, title: "Silent Reading Hall", desc: "No-noise zones for deep focus" },
  { icon: BookOpen, title: "Exam Books", desc: "UPSC, SSC, Banking resources" },
  { icon: Newspaper, title: "Daily News", desc: "National & local dailies" },
  { icon: Wind, title: "AC Environment", desc: "Fully climate controlled" },
  { icon: Layout, title: "Study Cabins", desc: "Individual partitioned spaces" },
];

const labFeatures = [
  { icon: UserCheck, title: "Expert Faculty Support", desc: "Dedicated mentors for computer classes" },
  { icon: Monitor, title: "Modern desktops", desc: "Latest high-perf systems" },
  { icon: Globe, title: "High-speed Web", desc: "Fiber optic connectivity" },
  { icon: Printer, title: "Print & Scan", desc: "Instant documentation services" },
  { icon: Code, title: "Coding Lab", desc: "Practise IDEs & environments" },
];

export default function Features() {
  return (
    <section id="facilities" className="py-24 bg-academic-beige dark:bg-slate-900 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">World-Class Facilities</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-academic-blue dark:text-white mb-6">
            Dual Learning <span className="italic text-academic-accent">Ecosystem</span>
          </h3>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Whether you prefer traditional paper-based study or digital skill development, we provide the perfect infrastructure.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Library Column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white dark:bg-slate-800 p-8 md:p-12 rounded-[3rem] shadow-xl border border-slate-100 dark:border-slate-700"
          >
            <div className="inline-flex items-center gap-3 px-4 py-2 bg-academic-blue/5 text-academic-blue rounded-full text-sm font-bold mb-8">
              <BookOpen className="w-5 h-5" />
              <span>Premium Library Facilities</span>
            </div>
            <div className="space-y-8">
              {libraryFeatures.map((item, i) => (
                <div key={i} className="flex gap-5 group">
                  <div className="w-12 h-12 bg-academic-beige dark:bg-slate-700 rounded-2xl flex items-center justify-center text-academic-blue group-hover:bg-academic-blue group-hover:text-white transition-all shrink-0">
                    <item.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-academic-blue dark:text-white mb-1">{item.title}</h4>
                    <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Computer Lab Column */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-slate-900 p-8 md:p-12 rounded-[3rem] shadow-2xl relative overflow-hidden"
          >
            {/* Backglow */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-academic-blue/20 rounded-full blur-[100px]"></div>
            
            <div className="relative z-10">
              <div className="inline-flex items-center gap-3 px-4 py-2 bg-white/10 text-white rounded-full text-sm font-bold mb-8">
                <Monitor className="w-5 h-5" />
                <span>Modern Computer Lab</span>
              </div>
              <div className="space-y-8">
                {labFeatures.map((item, i) => (
                  <div key={i} className="flex gap-5 group">
                    <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-white group-hover:bg-academic-accent transition-all shrink-0">
                      <item.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-white mb-1">{item.title}</h4>
                      <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-12 p-6 bg-white/5 border border-white/10 rounded-3xl backdrop-blur-sm">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-academic-accent rounded-full flex items-center justify-center text-white font-bold text-xl">
                    NS
                  </div>
                  <div>
                    <h5 className="font-bold text-white">Dedicated Expert Faculty</h5>
                    <p className="text-xs text-academic-accent font-bold uppercase tracking-widest">Lead Instructor: Neeraj Sharma</p>
                  </div>
                </div>
                <p className="mt-4 text-xs text-slate-400 leading-relaxed italic">
                  "Our goal is to bridge the digital gap by providing personal guidance to every student who wants to master computers."
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
