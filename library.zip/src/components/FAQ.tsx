import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Plus } from 'lucide-react';

const faqs = [
  {
    q: "Is there a trial period before membership?",
    a: "Yes! You can visit the library for a free 4-hour trial to experience the environment before choosing a membership plan."
  },
  {
    q: "Is the library open on Sundays and Holidays?",
    a: "Our Premium Monthly members have 24/7 biometric access, including weekends and public holidays. Standard members have 8 AM - 10 PM access."
  },
  {
    q: "Do you provide locker facility?",
    a: "Currently we don't provide lockers but we are working on it, soon will be provided."
  },
  {
    q: "Is internet usage limited?",
    a: "No, we provide unlimited high-speed fiber WiFi for all study-related purposes including video lectures and research."
  },
  {
    q: "Can I book a seat for a specific time?",
    a: "Yes, we have an online seat booking option for our regular members through our WhatsApp portal or at the reception desk."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 bg-academic-beige dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-academic-accent mb-4">FAQ</h2>
          <h3 className="text-4xl font-serif font-bold text-academic-blue dark:text-white">Common Questions</h3>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full text-left p-6 flex justify-between items-center group transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/50"
              >
                <span className="font-bold text-academic-blue dark:text-white transition-colors">{faq.q}</span>
                <div className={`p-2 rounded-full transition-transform duration-300 ${openIndex === index ? 'rotate-180 bg-academic-blue text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'}`}>
                  <ChevronDown className="w-4 h-4" />
                </div>
              </button>
              
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 text-slate-600 dark:text-slate-400 leading-relaxed border-t dark:border-slate-700 pt-4">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
